
import { GoogleGenAI, Chat } from "@google/genai";

let chat: Chat | null = null;

async function getChatInstance(): Promise<Chat> {
  if (chat) {
    return chat;
  }
  
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API_KEY environment variable not set");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  chat = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: 'You are CortexLuma, a powerful and creative AI assistant. Your goal is to help users brainstorm, generate ideas, and explore concepts with clarity and intelligence. Provide insightful, well-structured, and inspiring responses. Format your answers using Markdown for readability.',
    },
  });

  return chat;
}

export const chatWithGemini = async (prompt: string): Promise<string> => {
  try {
    const chatInstance = await getChatInstance();
    const result = await chatInstance.sendMessage({ message: prompt });
    return result.text;
  } catch (error) {
    console.error("Error communicating with Gemini API:", error);
    chat = null; // Reset chat session on error
    throw new Error("Failed to get response from AI. Please check your API key and network connection.");
  }
};
