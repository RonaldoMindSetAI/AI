
import React, { useState } from 'react';
import { SendIcon } from './IconComponents';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() && !isLoading) {
      onSendMessage(text);
      setText('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit(e as unknown as React.FormEvent);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex items-center space-x-3 bg-secondary rounded-xl p-2 border border-gray-700 focus-within:ring-2 focus-within:ring-accent">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Ask something luminous..."
        className="flex-1 bg-transparent focus:outline-none p-2 text-text-primary resize-none placeholder-text-secondary"
        rows={1}
        disabled={isLoading}
      />
      <button
        type="submit"
        disabled={isLoading}
        className="bg-accent text-white p-2 rounded-lg hover:bg-accent-hover disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
      >
        <SendIcon />
      </button>
    </form>
  );
};
