
import React from 'react';
import { BotIcon } from './IconComponents';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent flex items-center justify-center text-white">
        <BotIcon />
      </div>
      <div className="bg-secondary text-text-primary rounded-xl rounded-bl-none p-4 flex items-center space-x-2">
         <div className="w-2 h-2 bg-accent-hover rounded-full animate-bounce [animation-delay:-0.3s]"></div>
         <div className="w-2 h-2 bg-accent-hover rounded-full animate-bounce [animation-delay:-0.15s]"></div>
         <div className="w-2 h-2 bg-accent-hover rounded-full animate-bounce"></div>
      </div>
    </div>
  );
};
