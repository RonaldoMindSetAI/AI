
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="flex items-center justify-center p-4 bg-secondary shadow-md border-b border-gray-800">
      <h1 className="text-2xl font-bold tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
        CortexLuma
      </h1>
    </header>
  );
};
