
import React, { useEffect, useRef } from 'react';
import { Message, Sender } from '../types';
import { BotIcon, UserIcon, CopyIcon } from './IconComponents';

// Since marked is loaded from CDN, we need to declare it to TypeScript
declare global {
    interface Window {
        marked: any;
    }
}

interface ChatMessageProps {
  message: Message;
}

const renderMarkdown = (text: string) => {
    if (window.marked) {
        const rawMarkup = window.marked.parse(text, { breaks: true, gfm: true });
        return { __html: rawMarkup };
    }
    return { __html: text.replace(/\n/g, '<br />') }; // Fallback
};


export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.sender === Sender.User;
  const contentRef = useRef<HTMLDivElement>(null);

  const handleCopy = () => {
    if (contentRef.current) {
        navigator.clipboard.writeText(message.text);
    }
  };

  return (
    <div className={`flex items-start gap-4 ${isUser ? 'justify-end' : ''}`}>
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-accent flex items-center justify-center text-white">
          <BotIcon />
        </div>
      )}
      <div
        className={`max-w-xl p-4 rounded-xl shadow-lg ${
          isUser
            ? 'bg-accent text-white rounded-br-none'
            : 'bg-secondary text-text-primary rounded-bl-none'
        }`}
      >
        <div 
          ref={contentRef}
          className="prose prose-invert prose-sm max-w-none"
          dangerouslySetInnerHTML={renderMarkdown(message.text)}
        />
        {!isUser && (
            <button 
                onClick={handleCopy}
                className="mt-3 text-text-secondary hover:text-text-primary transition-colors"
                title="Copy text"
            >
                <CopyIcon />
            </button>
        )}
      </div>
      {isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-text-primary">
          <UserIcon />
        </div>
      )}
    </div>
  );
};
